﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace ExamenPascalFerlatte.Models
{
    public partial class Quiz
    {
        public Quiz()
        {
            Answers = new HashSet<Answer>();
            QuestionQuizzes = new HashSet<QuestionQuiz>();
        }

        public int QuizId { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string Email { get; set; }

        public virtual ICollection<Answer> Answers { get; set; }
        public virtual ICollection<QuestionQuiz> QuestionQuizzes { get; set; }
    }
}
