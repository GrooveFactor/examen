﻿using ExamenPascalFerlatte.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ExamenPascalFerlatte.Controllers
{
    public class HomeController : Controller
    {
        private readonly QuizExamenContext context;

        public HomeController(QuizExamenContext _context)
        {
            context = _context;
        }
        public IActionResult Index()
        {
           
            return View();
        }

        [HttpGet]
        // quand j'affiche le form
        public IActionResult newQuiz()
        {

            return View();
        }

        [HttpPost]
        // quand je soumets le form
        public IActionResult newQuiz(string txtName, string txtEmail, int txtEasy, int txtMedium, int txtHard)
        {
            Quiz quiz = new Quiz()
            {
                UserName = txtName,
                Email = txtEmail
            };
            context.Add<Quiz>(quiz);
            context.SaveChanges();

            int quizID = context.Quizzes.OrderBy(x => x.QuizId).Last().QuizId;
            var questionsEasy = context.Questions.Where(a => a.Category.Description == "Easy").Take(txtEasy).ToList();
            foreach (var q in questionsEasy)
            {
                QuestionQuiz questionQuiz = new QuestionQuiz()
                {
                    QuizId = quizID,
                    QuestionId = q.QuestionId

                };
                context.Add<QuestionQuiz>(questionQuiz);
                context.SaveChanges();
            }
            var questionsMedium = context.Questions.Where(a => a.Category.Description == "Medium").Take(txtMedium).ToList();
            foreach (var q in questionsMedium)
            {
                QuestionQuiz questionQuiz = new QuestionQuiz()
                {
                    QuizId = quizID,
                    QuestionId = q.QuestionId

                };
                context.Add<QuestionQuiz>(questionQuiz);
                context.SaveChanges();
            }
            var questionsHard = context.Questions.Where(a => a.Category.Description == "Hard").Take(txtHard).ToList();
            foreach (var q in questionsHard)
            {
                QuestionQuiz questionQuiz = new QuestionQuiz()
                {
                    QuizId = quizID,
                    QuestionId = q.QuestionId

                };
                context.Add<QuestionQuiz>(questionQuiz);
                context.SaveChanges();
            }
            return RedirectToAction("index");
        }

        [HttpGet]
        public IActionResult passQuiz()
        {
            return View();
        }

        [HttpPost]
        public IActionResult passQuiz(string txtName, string txtEmail)
        {
            var trouverQuiz=context.Quizzes.Where(c => c.UserName == txtName && c.Email == txtEmail);
            
            return View("trouverQuiz",trouverQuiz);
        }

        public IActionResult effectuerQuiz(int id)
            {
                var x = context.QuestionQuizzes.Where(x => x.QuizId == id).ToList();
                ViewBag.QuizId = id;
                return View(x);
            }
   

        public IActionResult sauvegardeReponse(int id)
        {
            foreach (var key in HttpContext.Request.Query.Keys)
            {
                StringValues someInt;
                HttpContext.Request.Query.TryGetValue(key, out someInt);
                int OptionId = Convert.ToInt32(someInt);
                Answer reponse = new Answer() { QuizId = id, OptionId = OptionId };
                context.Add<Answer>(reponse);
                context.SaveChanges();
                //Debug.WriteLine(someInt);
            }
            return View("Index");
        }

        public IActionResult reviewQuiz()
        {
            return View();
        }
        
        //public IActionResult reviewQuiz(string txtName, string txtEmail)
        //{
        //    var reviewQuiz = context.Quizzes.Where(c => c.UserName == txtName && c.Email == txtEmail);

        //    return View("reviewNote", reviewQuiz);
        //}

    }
}
